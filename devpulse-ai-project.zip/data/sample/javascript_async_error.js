// Sample 4: JavaScript Async / Unhandled Promise Rejection
// Intention: Fetch user data and format full name
async function getUserProfile(userId) {
    const response = await fakeApiFetch(userId);
    // Bug: If response is null or user.profile is undefined, reading properties throws TypeError
    return `${response.profile.firstName} ${response.profile.lastName}`;
}

function fakeApiFetch(id) {
    return Promise.resolve(id === 1 ? { profile: null } : null);
}

// TypeError: Cannot read properties of null (reading 'firstName')
getUserProfile(1).then(console.log).catch(console.error);
