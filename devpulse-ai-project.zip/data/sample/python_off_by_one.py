# Sample 1: Python Off-by-one / IndexError
# Intention: Calculate cumulative sum of list elements
def calculate_cumulative_sum(numbers):
    total = 0
    # Bug: using range(len(numbers) + 1) or <= len(numbers) causes IndexError
    for i in range(len(numbers) + 1):
        total += numbers[i]
    return total

sample_list = [10, 20, 30, 40]
# Error: IndexError: list index out of range
print(calculate_cumulative_sum(sample_list))
