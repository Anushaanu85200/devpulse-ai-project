// Sample 6: C++ Dangling Pointer / Stack Return Bug
// Intention: Create a temporary configuration counter and return reference
#include <iostream>

int* createCounter(int initialValue) {
    // Bug: local variable allocated on the call stack is destroyed upon function return
    int localCount = initialValue + 10;
    return &localCount; // Warning: address of local variable returned
}

int main() {
    int* ptr = createCounter(5);
    // Undefined behavior / Segmentation fault
    std::cout << "Value: " << *ptr << std::endl;
    return 0;
}
