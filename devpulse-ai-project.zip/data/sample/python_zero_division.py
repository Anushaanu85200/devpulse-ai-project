# Sample 2: Python ZeroDivisionError
# Intention: Calculate class average test score
def compute_average(scores):
    # Bug: If scores list is empty or sum is divided without check
    return sum(scores) / len(scores)

empty_scores = []
# Error: ZeroDivisionError: division by zero
print(compute_average(empty_scores))
