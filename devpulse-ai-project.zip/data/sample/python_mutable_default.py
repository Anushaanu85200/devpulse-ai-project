# Sample 3: Python Mutable Default Argument Bug
# Intention: Append items to a user cart with an empty default list
def add_to_cart(item, cart=[]):
    # Bug: Mutable default argument retains state across multiple function calls
    cart.append(item)
    return cart

cart1 = add_to_cart("Apple")
print("Cart 1:", cart1)

cart2 = add_to_cart("Banana")
# Unexpected Output: Cart 2 contains ['Apple', 'Banana'] instead of ['Banana']!
print("Cart 2 (expected only Banana):", cart2)
