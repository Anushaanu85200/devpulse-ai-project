// Sample 5: Java NullPointerException
// Intention: Find maximum string length in an array
public class StringAnalyzer {
    public static int getMaxWordLength(String[] words) {
        int maxLen = 0;
        // Bug: If any entry in words is null, calling word.length() triggers NullPointerException
        for (String word : words) {
            if (word.length() > maxLen) {
                maxLen = word.length();
            }
        }
        return maxLen;
    }

    public static void main(String[] args) {
        String[] terms = {"developer", null, "debugging"};
        // Exception in thread "main" java.lang.NullPointerException
        System.out.println("Max length: " + getMaxWordLength(terms));
    }
}
