"""backend/utils/validators.py
Input, file, and static code validators for DevPulse AI.
Ensures clean input handling and safe execution constraints.
"""

import ast
import re
from typing import Dict, Any, Optional

ALLOWED_EXTENSIONS = {
    ".py", ".js", ".jsx", ".ts", ".tsx",
    ".java", ".cpp", ".cc", ".c", ".h", ".hpp",
    ".cs", ".go", ".rs", ".sql", ".php", ".rb", ".txt"
}

ALLOWED_LANGUAGES = [
    "python", "javascript", "typescript", "java",
    "c++", "c", "c#", "go", "sql", "php", "ruby"
]

MAX_CODE_CHARS = 30000
MAX_FILE_BYTES = 1024 * 1024  # 1 MB


def normalize_language(lang_input: str) -> str:
    """Normalize language input name."""
    clean = (lang_input or "").strip().lower()
    mapping = {
        "py": "python",
        "python3": "python",
        "js": "javascript",
        "node": "javascript",
        "ts": "typescript",
        "cplusplus": "c++",
        "cpp": "c++",
        "c#": "c#",
        "csharp": "c#",
        "golang": "go",
        "postgres": "sql",
        "mysql": "sql",
    }
    return mapping.get(clean, clean)


def validate_code_input(code: Optional[str], language: str = "python") -> str:
    """Validates submitted code string. Raises ValueError if invalid."""
    if not code or not code.strip():
        raise ValueError("Please provide a code snippet to analyze. Code cannot be empty.")

    clean_code = code.strip()

    if len(clean_code) < 3:
        raise ValueError("Code snippet is too short to analyze. Please provide at least one valid statement.")

    if len(clean_code) > MAX_CODE_CHARS:
        raise ValueError(
            f"Code snippet exceeds the maximum permitted length of {MAX_CODE_CHARS:,} characters. "
            f"Currently {len(clean_code):,} characters. Please submit a smaller function or module."
        )

    return clean_code


def validate_uploaded_file(uploaded_file: Any) -> Dict[str, Any]:
    """Validates an uploaded file object (Streamlit UploadedFile or file-like)."""
    if uploaded_file is None:
        raise ValueError("No file uploaded.")

    filename = getattr(uploaded_file, "name", "unknown.txt")
    size = getattr(uploaded_file, "size", 0)

    # Extension check
    dot_idx = filename.rfind(".")
    ext = filename[dot_idx:].lower() if dot_idx != -1 else ""

    if ext not in ALLOWED_EXTENSIONS:
        raise ValueError(
            f"Unsupported file extension '{ext}'. "
            f"Allowed extensions: {', '.join(sorted(ALLOWED_EXTENSIONS))}"
        )

    if size > MAX_FILE_BYTES:
        raise ValueError(
            f"File '{filename}' exceeds maximum allowed size of 1MB (current: {size / 1024:.1f} KB)."
        )

    try:
        content_bytes = uploaded_file.getvalue() if hasattr(uploaded_file, "getvalue") else uploaded_file.read()
        decoded_text = content_bytes.decode("utf-8", errors="replace")
    except Exception as exc:
        raise ValueError(f"Failed to read file as text: {exc}")

    # Infer language from extension
    ext_lang_map = {
        ".py": "python",
        ".js": "javascript",
        ".jsx": "javascript",
        ".ts": "typescript",
        ".tsx": "typescript",
        ".java": "java",
        ".cpp": "c++",
        ".cc": "c++",
        ".c": "c",
        ".h": "c",
        ".cs": "c#",
        ".go": "go",
        ".sql": "sql",
        ".php": "php",
        ".rb": "ruby",
        ".txt": "python"
    }
    inferred_language = ext_lang_map.get(ext, "python")

    validate_code_input(decoded_text, inferred_language)

    return {
        "filename": filename,
        "language": inferred_language,
        "content": decoded_text,
        "size_bytes": size
    }


def check_python_syntax(code: str) -> Dict[str, Any]:
    """Uses Python's native AST parser to deterministically detect syntax errors."""
    try:
        parsed = ast.parse(code)
        # Count nodes for complexity hint
        num_functions = sum(1 for node in ast.walk(parsed) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)))
        num_classes = sum(1 for node in ast.walk(parsed) if isinstance(node, ast.ClassDef))
        num_loops = sum(1 for node in ast.walk(parsed) if isinstance(node, (ast.For, ast.While)))

        return {
            "is_valid_syntax": True,
            "error_type": None,
            "line": None,
            "col": None,
            "message": "Python syntax is grammatically valid.",
            "metrics": {
                "functions": num_functions,
                "classes": num_classes,
                "loops": num_loops
            }
        }
    except (SyntaxError, IndentationError) as err:
        return {
            "is_valid_syntax": False,
            "error_type": type(err).__name__,
            "line": err.lineno,
            "col": err.offset,
            "message": err.msg or str(err),
            "snippet": err.text.strip() if err.text else ""
        }
    except Exception as exc:
        return {
            "is_valid_syntax": False,
            "error_type": "ParseException",
            "line": None,
            "col": None,
            "message": str(exc),
            "snippet": ""
        }
