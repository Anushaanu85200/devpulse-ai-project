"""backend/utils
Validation and helper utilities for DevPulse AI.
"""
