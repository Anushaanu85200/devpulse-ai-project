"""backend/config.py
Configuration loader following GMRIT Handbook guidelines.
Safely retrieves secrets from st.secrets, .env, or Streamlit session_state without exposing keys.
"""

import os
from typing import Optional, Dict, Any
from dotenv import load_dotenv

# Load local .env if available
load_dotenv()


def get_setting(name: str, default: Optional[str] = None) -> Optional[str]:
    """Retrieve setting with hierarchy:
    1. streamlit session_state (user entered key in UI)
    2. streamlit secrets (secrets.toml or Streamlit Cloud Settings > Secrets)
    3. os.environ / .env
    4. default value
    """
    # 1. Check session state (safely without raising if streamlit is not running)
    try:
        import streamlit as st
        if hasattr(st, "session_state") and name in st.session_state and st.session_state[name]:
            return str(st.session_state[name]).strip()
    except Exception:
        pass

    # 2. Check st.secrets
    try:
        import streamlit as st
        if hasattr(st, "secrets") and name in st.secrets and st.secrets[name]:
            return str(st.secrets[name]).strip()
    except Exception:
        pass

    # 3. Check os.environ
    env_val = os.getenv(name)
    if env_val is not None and env_val.strip():
        return env_val.strip()

    return default


def get_active_provider_info() -> Dict[str, Any]:
    """Inspects available keys and determines the active LLM provider.
    Returns status metadata without revealing the secret keys.
    """
    provider_pref = (get_setting("LLM_PROVIDER") or "").lower()
    gemini_key = get_setting("GEMINI_API_KEY")
    groq_key = get_setting("GROQ_API_KEY")

    if provider_pref == "groq" and groq_key:
        return {
            "provider": "groq",
            "model": get_setting("GROQ_MODEL", "llama-3.3-70b-versatile"),
            "has_key": True,
            "status": "Connected to Groq (High Speed)",
            "mode": "live"
        }

    if (provider_pref == "gemini" or not provider_pref) and gemini_key:
        return {
            "provider": "gemini",
            "model": get_setting("GEMINI_MODEL", "gemini-1.5-flash"),
            "has_key": True,
            "status": "Connected to Google Gemini AI",
            "mode": "live"
        }

    if groq_key:
        return {
            "provider": "groq",
            "model": get_setting("GROQ_MODEL", "llama-3.3-70b-versatile"),
            "has_key": True,
            "status": "Connected to Groq (High Speed)",
            "mode": "live"
        }

    if gemini_key:
        return {
            "provider": "gemini",
            "model": get_setting("GEMINI_MODEL", "gemini-1.5-flash"),
            "has_key": True,
            "status": "Connected to Google Gemini AI",
            "mode": "live"
        }

    # No key configured: Safe Offline / Educational Demo Mode
    return {
        "provider": "mock",
        "model": "offline-rule-based-analyzer",
        "has_key": False,
        "status": "Offline Educational Mode (Zero-Config / Rule-based AST)",
        "mode": "demo"
    }
