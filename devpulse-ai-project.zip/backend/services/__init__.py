"""backend/services
LLM integration and AI reasoning services.
"""
