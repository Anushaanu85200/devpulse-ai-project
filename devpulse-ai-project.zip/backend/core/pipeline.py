"""backend/core/pipeline.py
Core pipeline for DevPulse AI: Code Explainer and Debugging Tutor.
Orchestrates static analysis, LLM reasoning, line-by-line diff generation,
complexity analysis, Socratic hints, and synthetic test suites.
"""

import difflib
import json
import logging
import re
from datetime import datetime
from typing import Dict, Any, List, Optional

from backend.config import get_active_provider_info
from backend.services.llm_service import ask_llm
from backend.utils.validators import (
    validate_code_input,
    normalize_language,
    check_python_syntax
)

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are DevPulse AI, an expert code explanation and debugging tutor for programming students.
Your job is to analyze buggy or confusing code, explain it in simple terms, diagnose errors, propose minimal elegant fixes,
and generate educational test cases and Socratic hints.

You MUST respond strictly in valid JSON format matching this schema:
{
  "code_explanation": "Clear, plain-language explanation of what the original code is attempting to do and how it operates.",
  "error_diagnosis": "Detailed root-cause analysis of the bug or error, explaining why it occurs and pinpointing the exact line(s).",
  "minimal_fix_summary": "Concise summary of the minimal surgical fix needed to resolve the issue cleanly.",
  "corrected_code": "The full corrected and runnable code, preserving the author's original style without unnecessary rewrites.",
  "line_by_line_changes": [
    {
      "line": "Line number or code section",
      "change": "What was changed",
      "explanation": "Why this specific change fixes the issue"
    }
  ],
  "complexity_original": "e.g. Time: O(n), Space: O(1)",
  "complexity_corrected": "e.g. Time: O(n), Space: O(1)",
  "complexity_notes": "Explanation of whether time or space complexity was improved or preserved, and why.",
  "hints": [
    "Hint 1 (Gentle clue / high-level conceptual observation)",
    "Hint 2 (Pinpoint the specific variable, loop, or condition)",
    "Hint 3 (Concrete nudge towards the exact fix without spoiling completely)"
  ],
  "test_cases": [
    {
      "description": "Short title of the test case",
      "input": "Sample input value or call signature",
      "expected_output": "Expected return value or behavior",
      "test_type": "standard / edge_case / boundary / regression"
    }
  ]
}
Do NOT include any commentary outside the JSON block. Output ONLY the raw JSON string."""


def generate_diff(original: str, corrected: str) -> str:
    """Generates a standard unified diff string between original and corrected code."""
    orig_lines = original.splitlines(keepends=True)
    corr_lines = corrected.splitlines(keepends=True)

    diff = difflib.unified_diff(
        orig_lines,
        corr_lines,
        fromfile="original_code",
        tofile="corrected_code",
        lineterm=""
    )
    return "".join(diff)


def extract_json_from_llm(raw_response: str) -> Dict[str, Any]:
    """Robustly extracts JSON from an LLM response string."""
    cleaned = raw_response.strip()

    # If wrapped in markdown code fence
    fence_match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", cleaned)
    if fence_match:
        cleaned = fence_match.group(1).strip()

    # Find the outermost { and }
    start_idx = cleaned.find("{")
    end_idx = cleaned.rfind("}")

    if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
        cleaned = cleaned[start_idx:end_idx + 1]

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError as err:
        logger.warning(f"Direct JSON parsing failed ({err}), attempting fallback normalization.")
        # Fallback basic cleanup: replace trailing commas before } or ]
        normalized = re.sub(r",\s*([\]}])", r"\1", cleaned)
        try:
            return json.loads(normalized)
        except Exception:
            # If all parsing fails, package raw output safely
            return {
                "code_explanation": raw_response[:500],
                "error_diagnosis": "The AI provided an unstructured explanation. See the full response below.",
                "minimal_fix_summary": "Please review the corrected code block.",
                "corrected_code": raw_response,
                "line_by_line_changes": [
                    {"line": "All", "change": "Model provided general fix", "explanation": "See generated output."}
                ],
                "complexity_original": "Not parsed",
                "complexity_corrected": "Not parsed",
                "complexity_notes": "",
                "hints": ["Review the error message and trace variables step-by-step."],
                "test_cases": []
            }


def process_debug_pipeline(
    code: str,
    language: str = "python",
    error_message: str = "",
    mode: str = "full"
) -> Dict[str, Any]:
    """Primary pipeline function following GMRIT Handbook Project 06 specifications.

    Parameters:
        code: The source code snippet to analyze
        language: Programming language name (e.g., 'python', 'javascript')
        error_message: Optional error message or traceback pasted by student
        mode: 'full' (all features), 'hints' (hint-first), 'explain' (explanation only)

    Returns:
        Structured dictionary with explanation, diagnosis, fix, diff, test cases, and metadata.
    """
    clean_code = validate_code_input(code, language)
    norm_lang = normalize_language(language)

    # Deterministic AST check if Python
    ast_findings: Optional[Dict[str, Any]] = None
    if norm_lang == "python":
        ast_findings = check_python_syntax(clean_code)

    # Build prompt
    prompt_parts = [
        f"Language: {norm_lang}",
        f"Analysis Mode: {mode.upper()}",
    ]

    if error_message and error_message.strip():
        prompt_parts.append(f"Error Message / Traceback:\n```\n{error_message.strip()}\n```")
    elif ast_findings and not ast_findings.get("is_valid_syntax"):
        ast_err = ast_findings.get("message", "Syntax error detected")
        ast_line = ast_findings.get("line")
        prompt_parts.append(f"Static Syntax Analyzer Finding: {ast_err} at line {ast_line}")
    else:
        prompt_parts.append("Error Message: (None provided - detect logic bugs, potential exceptions, or anti-patterns)")

    prompt_parts.append(f"User Code:\n```{norm_lang}\n{clean_code}\n```")

    if mode == "hints":
        prompt_parts.append(
            "IMPORTANT: The user requested HINT-FIRST mode. Make the 'hints' array exceptionally clear, progressive, and pedagogical so the student can solve the bug independently before looking at the fix."
        )

    user_prompt = "\n\n".join(prompt_parts)

    # Call AI or offline fallback
    provider_info = get_active_provider_info()
    raw_response = ask_llm(user_prompt, system_prompt=SYSTEM_PROMPT)
    parsed = extract_json_from_llm(raw_response)

    corrected_code = parsed.get("corrected_code", clean_code)
    unified_diff = generate_diff(clean_code, corrected_code)

    return {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "language": norm_lang,
        "original_code": clean_code,
        "error_message": error_message.strip() if error_message else None,
        "code_explanation": parsed.get("code_explanation", "No explanation available."),
        "error_diagnosis": parsed.get("error_diagnosis", "No error detected or diagnosed."),
        "minimal_fix_summary": parsed.get("minimal_fix_summary", "Review the corrected code."),
        "corrected_code": corrected_code,
        "line_by_line_changes": parsed.get("line_by_line_changes", []),
        "unified_diff": unified_diff,
        "complexity": {
            "original": parsed.get("complexity_original", "N/A"),
            "corrected": parsed.get("complexity_corrected", "N/A"),
            "notes": parsed.get("complexity_notes", "")
        },
        "hints": parsed.get("hints", []),
        "test_cases": parsed.get("test_cases", []),
        "ast_findings": ast_findings,
        "provider_used": provider_info["provider"],
        "model_used": provider_info["model"],
        "mode": mode
    }
