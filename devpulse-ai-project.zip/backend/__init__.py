"""DevPulse AI Backend Package
Provides configuration, validation, LLM services, and core debugging pipelines.
"""
__version__ = "1.0.0"
