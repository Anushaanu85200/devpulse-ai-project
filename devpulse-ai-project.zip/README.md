# DevPulse AI — Code Explainer and Debugging Tutor

An intelligent, pedagogical AI code explanation and debugging tutor designed to help programming students understand error messages, identify root causes, receive minimal surgical fixes, study line-by-line diffs, and practice Socratic problem-solving.

---

## 1. Problem Statement
Beginner programmers and computer science students frequently encounter cryptic compiler, interpreter, and runtime error messages (such as `IndexError`, `ZeroDivisionError`, `NullPointerException`, or unhandled asynchronous exceptions). Instead of comprehending *why* the failure occurred, students often resort to blind copy-pasting or random trial-and-error without building conceptual intuition. DevPulse AI bridges this educational gap by providing clear, plain-language explanations, diagnosing root causes, proposing minimal corrected code with visual git diffs, generating comprehensive edge-case test suites, and offering progressive Socratic hints.

---

## 2. Objectives
- **Objective 1:** Deconstruct complex and confusing code into understandable, plain-language explanations tailored for beginner developers.
- **Objective 2:** Diagnose root causes of syntax, logic, and runtime errors, providing surgical minimal fixes rather than overwhelming complete rewrites.
- **Objective 3:** Foster independent thinking through a **Socratic Hint-First** mode that guides students with progressive clues before unveiling the final solution.
- **Objective 4:** Ensure complete safety and reliability by performing static AST syntax validation and never executing arbitrary user code on the server.

---

## 3. Features
- **Multi-Language Support:** Analyzes Python, JavaScript, TypeScript, Java, C++, C, C#, Go, and SQL.
- **Static AST Syntax Analyzer:** Built-in Python Abstract Syntax Tree parser that deterministically catches syntax errors, line numbers, and indentation issues with zero latency.
- **Plain-English Explainer:** Explains algorithm intent, control flow, inputs, and expected outputs clearly.
- **Root-Cause Error Diagnosis:** Pinpoints faulty lines and provides educational breakdowns of why exceptions happen.
- **Minimal Surgical Fixes:** Suggests the smallest clean modification to repair the bug while preserving the author's original style.
- **Visual Git Diff Viewer:** Color-coded additions (`+` green) and deletions (`-` red) for instant visual comparison.
- **Line-by-Line Changes Table:** Structured table explaining each modification made and its specific rationale.
- **Algorithmic Complexity Comparison:** Evaluates Time and Space complexity ($O(n)$, $O(1)$, etc.) before and after the fix.
- **Progressive Socratic Hints:** 3-tier progressive hint disclosure (Level 1: Concept Clue, Level 2: Fault Pinpoint, Level 3: Near-Solution Nudge).
- **Synthetic Test Suite & Edge Cases:** Generates unit tests covering standard cases, null boundaries, empty inputs, and regression checks.
- **Multi-Source Key Management:** Seamlessly connects to Google Gemini API (`gemini-1.5-flash`), Groq API (`llama-3.3-70b-versatile`), or falls back to an intelligent zero-config Offline Tutor Engine.
- **Multipage Capabilities:** Includes an Interactive Debug Lab (`pages/2_Interactive_Debug_Lab.py`) and Session History & Analytics (`pages/1_History_and_Analytics.py`) with JSON/Markdown export.

---

## 4. Technology Stack
- **Language:** Python 3.11 / 3.12
- **Frontend / UI:** Streamlit 1.41+ with custom CSS (modern, clean, responsive developer layout)
- **Backend Logic:** Modular Python package (`backend/` with `config.py`, `services/`, `core/`, `utils/`)
- **LLM Providers:** Google Gemini API (`google-generativeai`), Groq API (`groq`), plus an offline heuristic rule engine
- **Static Analysis:** Python native `ast` and `difflib` modules
- **Data Handling:** Pandas, JSON, CSV
- **Testing:** Pytest 9.x
- **Deployment Platform:** Streamlit Community Cloud

---

## 5. Architecture
The application adheres strictly to the modular architectural separation mandated in Section 4 of the GMRIT Handbook:

```
[User Input: Code / Error / File]
                 │
                 ▼
[Input Validators (backend/utils/validators.py)] ──► [AST Syntax Checker]
                 │
                 ▼
[Core Pipeline (backend/core/pipeline.py)] ────────► [Unified Diff Generator]
                 │
                 ▼
[LLM Service (backend/services/llm_service.py)] ───► [Gemini / Groq / Offline Tutor]
                 │
                 ▼
[Streamlit Frontend (app.py & pages/)] ────────────► [5-Tab Pedagogical Output]
```

![Architecture Diagram](assets/architecture_diagram.svg)

---

## 6. Project Structure
```
devpulse-ai/
├── app.py                             # Streamlit frontend entry point
├── pages/                             # Multipage apps
│   ├── 1_History_and_Analytics.py     # Session history, metrics, and JSON/MD export
│   └── 2_Interactive_Debug_Lab.py     # AST Syntax Inspector and side-by-side comparator
├── components/                        # Reusable UI widgets and presentation layer
│   ├── __init__.py
│   └── ui_components.py               # Custom CSS, diff viewer, headers, hint expanders
├── backend/                           # Pure Python backend package (no UI code)
│   ├── __init__.py
│   ├── config.py                      # Multi-source secret loader (st.secrets -> .env)
│   ├── services/
│   │   ├── __init__.py
│   │   └── llm_service.py             # Gemini, Groq, and offline heuristic tutor
│   ├── core/
│   │   ├── __init__.py
│   │   └── pipeline.py                # Main debugging pipeline and diff logic
│   └── utils/
│       ├── __init__.py
│       └── validators.py              # Input validation and deterministic AST checker
├── data/
│   └── sample/                        # Realistic sample buggy snippets
│       ├── python_off_by_one.py
│       ├── python_zero_division.py
│       ├── python_mutable_default.py
│       ├── javascript_async_error.js
│       ├── java_null_pointer.java
│       └── cpp_dangling_pointer.cpp
├── tests/                             # Automated test suite (pytest)
│   ├── __init__.py
│   ├── test_validators.py             # 8 unit tests for input and AST validation
│   └── test_pipeline.py               # 5 unit tests for pipeline, diff, and mock
├── assets/                            # Documentation diagrams and visual assets
│   └── architecture_diagram.svg
├── .streamlit/
│   ├── config.toml                    # Clean, modern theme configuration
│   └── secrets.toml                   # Local secrets (gitignored)
├── .env.example                       # Placeholder environment variable template
├── .gitignore                         # Protects secrets, .env, and caches
├── requirements.txt                   # Deployment dependencies
├── README.md                          # Mandatory 17-section documentation
└── LICENSE                            # MIT License
```

---

## 7. Prerequisites
- **Operating System:** Windows, macOS, or Linux
- **Python:** Version 3.11 or 3.12 installed
- **Git:** Installed for version control and deployment
- **API Access (Optional):** Free Gemini API key from [Google AI Studio](https://aistudio.google.com/) or Groq API key from [Groq Console](https://console.groq.com/). *Note: If no API key is provided, the application runs seamlessly in Offline Educational Mode.*

---

## 8. Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/<your-username>/devpulse-ai.git
   cd devpulse-ai
   ```

2. **Create and activate a virtual environment:**
   - *Windows PowerShell:*
     ```powershell
     py -3.11 -m venv .venv
     .venv\Scripts\Activate.ps1
     ```
   - *Windows Command Prompt:*
     ```cmd
     py -3.11 -m venv .venv
     .venv\Scripts\activate.bat
     ```
   - *macOS / Linux:*
     ```bash
     python3 -m venv .venv
     source .venv/bin/activate
     ```

3. **Install required dependencies:**
   ```bash
   pip install --upgrade pip
   pip install -r requirements.txt
   ```

4. **Configure environment variables:**
   ```bash
   copy .env.example .env
   ```
   Open `.env` and paste your Gemini or Groq API key (or enter it directly via the sidebar in the UI).

---

## 9. Run the Application
Launch the application from the root project directory:
```bash
streamlit run app.py
```
Open your browser at `http://localhost:8501`.

---

## 10. How to Use
1. **Choose Tutoring Mode:** Select *Full Debug & Explainer*, *Socratic Hint-First*, *Code Explainer Only*, or *Test Suite Generator* from the sidebar.
2. **Select Language & Input:** Choose your language (e.g. Python, JS, Java, C++) and paste your code snippet, or pick one from the **Quick Presets** dropdown.
3. **Add Error Message (Optional):** Paste compiler or interpreter terminal output (e.g., `IndexError: list index out of range`).
4. **Click "Diagnose & Debug":** DevPulse AI processes the code through AST verification, generates the root-cause diagnosis, displays the corrected code with unified git diffs, analyzes complexity, and produces edge-case tests.
5. **Explore the Tabs:**
   - **Tab 1 (Explanation & Diagnosis):** Read what the code does and the technical cause of the error.
   - **Tab 2 (Corrected Code & Changes):** View the corrected code and inspect the line-by-line modification table.
   - **Tab 3 (Diff & Complexity):** See exact line additions and deletions, and check Time/Space complexity changes.
   - **Tab 4 (Edge Cases & Tests):** Review generated unit test cases.
   - **Tab 5 (Socratic Hints):** Expand progressive hints to learn iteratively.
6. **Visit Secondary Pages:** Click **History & Analytics** in the sidebar to review and export past debug sessions, or **Interactive Debug Lab** to inspect raw AST trees.

---

## 11. Configuration
Settings are configured via `.env` (locally) or Streamlit Cloud `Secrets` (when deployed).

| Variable Name | Required | Default Value | Description |
|---|---|---|---|
| `LLM_PROVIDER` | No | `gemini` | `gemini`, `groq`, or `mock` (offline) |
| `GEMINI_API_KEY` | Optional | None | Google AI Studio API Key |
| `GEMINI_MODEL` | No | `gemini-1.5-flash` | Gemini model name |
| `GROQ_API_KEY` | Optional | None | Groq API Key |
| `GROQ_MODEL` | No | `llama-3.3-70b-versatile` | Groq LLaMA model name |

*Never commit `.env` or `.streamlit/secrets.toml` to GitHub!*

---

## 12. Testing
Run the complete automated test suite with pytest:
```bash
pytest -v
```
All 13 automated test cases validate input boundaries, empty checks, language normalization, deterministic AST syntax errors, git diffs, JSON extraction, and pipeline executions.

---

## 13. Screenshots / Demo
- **Live Streamlit Community Cloud URL:** `https://devpulse-ai.streamlit.app` (Placeholder for student deployment)
- **Demo Video:** A 3-minute video walkthrough showcasing error diagnosis, Socratic hints, and AST validation.

---

## 14. Known Limitations
- **No Arbitrary Server Execution:** DevPulse AI strictly tutors and explains code statically; it never runs arbitrary user code directly on the server for security reasons.
- **Language AST Coverage:** Real-time deep AST node inspection is currently implemented for Python; other languages rely on static regex and LLM reasoning.
- **Provider Quota Limits:** Free-tier Gemini and Groq API keys are subject to provider rate limits (typically 15 RPM). When rate-limited, DevPulse AI automatically falls back to Offline Educational Mode.

---

## 15. Privacy and Responsible Use
- **Data Storage:** All snippet processing is ephemeral. Code is stored exclusively in Streamlit's temporary in-memory session state and is deleted upon tab closure.
- **Academic Integrity:** DevPulse AI is designed as a learning companion. Students are encouraged to use **Hint-First Mode** to reason through their own logic rather than submitting AI code unverified.
- **Sensitive Data:** Never upload API keys, passwords, student IDs, or proprietary codebases.

---

## 16. Future Enhancements
- Integration of Docker-based ephemeral isolated sandboxes for live test execution.
- Support for AST inspection in JavaScript, TypeScript, and Java.
- VS Code and JetBrains IDE extensions connecting to DevPulse backend API.
- Voice-assisted explanations and spoken tutor responses.

---

## 17. Credits and License
- Developed as part of the GMRIT Grand AI & NLP Student Projects Handbook (Project 06: DevPulse AI).
- Built using [Streamlit](https://streamlit.io/), [Google Generative AI](https://ai.google.dev/), [Groq](https://groq.com/), and [Python](https://www.python.org/).
- Licensed under the **MIT License**.
