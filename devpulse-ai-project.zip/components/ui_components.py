"""components/ui_components.py
Visual presentation layer for DevPulse AI.
Provides clean, modern, professional developer aesthetics (crisp light/slate theme,
intuitive metric cards, progressive Socratic hints, and clear diff visualization).
"""

import html
import streamlit as st
from typing import Dict, Any, List


def apply_custom_styles():
    """Injects professional, modern SaaS-grade CSS styling into the Streamlit app.
    Avoids dingy/dark-web looks; uses clean slate, crisp indigo, and readable typography.
    """
    st.markdown(
        """
        <style>
        /* Import clean modern font */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap');

        html, body, [class*="css"] {
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
            color: #1E293B;
        }

        /* Top Brand Header */
        .brand-header-box {
            background: linear-gradient(135deg, #EEF2FF 0%, #F5F3FF 50%, #F0FDF4 100%);
            border: 1px solid #E0E7FF;
            border-radius: 16px;
            padding: 24px 28px;
            margin-bottom: 24px;
            box-shadow: 0 4px 12px rgba(79, 70, 229, 0.04);
        }
        .brand-title {
            font-size: 28px;
            font-weight: 800;
            color: #1E1B4B;
            letter-spacing: -0.5px;
            margin-bottom: 6px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .brand-badge {
            background: #4F46E5;
            color: #FFFFFF;
            font-size: 12px;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 20px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .brand-subtitle {
            font-size: 15px;
            color: #475569;
            font-weight: 500;
            line-height: 1.5;
            margin: 0;
        }

        /* Custom Cards */
        .dev-card {
            background: #FFFFFF;
            border: 1px solid #E2E8F0;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 16px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);
            transition: all 0.2s ease;
        }
        .dev-card:hover {
            border-color: #CBD5E1;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }
        .dev-card-title {
            font-size: 16px;
            font-weight: 700;
            color: #0F172A;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* Diff styling */
        .diff-container {
            font-family: 'JetBrains Mono', monospace;
            font-size: 13px;
            line-height: 1.6;
            background: #F8FAFC;
            border: 1px solid #E2E8F0;
            border-radius: 8px;
            padding: 14px;
            overflow-x: auto;
        }
        .diff-line-add {
            background-color: #DCFCE7;
            color: #166534;
            padding: 2px 6px;
            border-radius: 4px;
            display: block;
            margin: 1px 0;
        }
        .diff-line-del {
            background-color: #FEE2E2;
            color: #991B1B;
            padding: 2px 6px;
            border-radius: 4px;
            display: block;
            margin: 1px 0;
        }
        .diff-line-info {
            color: #64748B;
            font-weight: 600;
            display: block;
            margin: 4px 0;
        }
        .diff-line-normal {
            color: #334155;
            display: block;
        }

        /* Status Pills */
        .status-pill {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 9999px;
            font-size: 13px;
            font-weight: 600;
        }
        .status-live {
            background-color: #DCFCE7;
            color: #15803D;
            border: 1px solid #BBF7D0;
        }
        .status-demo {
            background-color: #FEF3C7;
            color: #B45309;
            border: 1px solid #FDE68A;
        }

        /* Metric Box */
        .metric-pill-box {
            display: flex;
            gap: 12px;
            margin: 14px 0;
            flex-wrap: wrap;
        }
        .metric-item {
            background: #F1F5F9;
            border: 1px solid #E2E8F0;
            border-radius: 8px;
            padding: 8px 14px;
            flex: 1;
            min-width: 140px;
        }
        .metric-item-label {
            font-size: 11px;
            font-weight: 700;
            color: #64748B;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .metric-item-value {
            font-size: 16px;
            font-weight: 800;
            color: #1E293B;
            margin-top: 2px;
        }

        /* Notice banner */
        .guardrail-notice {
            background: #F8FAFC;
            border-left: 4px solid #6366F1;
            padding: 12px 16px;
            border-radius: 0 8px 8px 0;
            font-size: 13px;
            color: #475569;
            margin-top: 20px;
        }
        </style>
        """,
        unsafe_allow_html=True
    )


def render_header(provider_info: Dict[str, Any]):
    """Renders the top branding card with current provider connectivity status."""
    is_live = provider_info.get("mode") == "live"
    status_class = "status-live" if is_live else "status-demo"
    status_icon = "🟢" if is_live else "🟡"
    status_text = provider_info.get("status", "System Ready")

    st.markdown(
        f"""
        <div class="brand-header-box">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 12px;">
                <div>
                    <div class="brand-title">
                        <span>⚡ DevPulse AI</span>
                        <span class="brand-badge">Project 06</span>
                    </div>
                    <p class="brand-subtitle">
                        Intelligent Code Explainer & Socratic Debugging Tutor for Engineering Students.
                        Identify errors, understand root causes, receive minimal fixes, and master edge cases.
                    </p>
                </div>
                <div class="status-pill {status_class}">
                    <span>{status_icon}</span>
                    <span>{html.escape(status_text)}</span>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )


def render_diff_viewer(diff_text: str):
    """Renders formatted unified git diff with clear visual styling."""
    if not diff_text or not diff_text.strip():
        st.info("No code modifications needed — the original code is already identical to the suggestion.")
        return

    lines_html = []
    for line in diff_text.splitlines():
        escaped = html.escape(line)
        if line.startswith("+++") or line.startswith("---") or line.startswith("@@"):
            lines_html.append(f'<span class="diff-line-info">{escaped}</span>')
        elif line.startswith("+"):
            lines_html.append(f'<span class="diff-line-add">{escaped}</span>')
        elif line.startswith("-"):
            lines_html.append(f'<span class="diff-line-del">{escaped}</span>')
        else:
            lines_html.append(f'<span class="diff-line-normal">&nbsp;{escaped}</span>')

    full_html = f'<div class="diff-container">{"".join(lines_html)}</div>'
    st.markdown(full_html, unsafe_allow_html=True)


def render_hints_section(hints: List[str]):
    """Renders progressive disclosure Socratic hints."""
    if not hints:
        st.info("No hints available for this snippet.")
        return

    st.markdown("### 🎓 Socratic Hint-First Tutoring")
    st.caption("Try solving the bug yourself using these progressive hints before looking at the corrected code!")

    for idx, hint in enumerate(hints, start=1):
        if idx == 1:
            st.info(f"💡 **Level 1 (Concept Clue):** {hint}")
        elif idx == 2:
            with st.expander(f"🔍 **Level 2 (Fault Pinpoint):** Click to reveal hint 2"):
                st.write(hint)
        else:
            with st.expander(f"🎯 **Level 3 (Near Solution):** Click to reveal hint 3"):
                st.write(hint)


def render_complexity_badge(complexity: Dict[str, Any]):
    """Renders visual complexity comparison cards."""
    orig = complexity.get("original", "O(n)")
    corr = complexity.get("corrected", "O(n)")
    notes = complexity.get("notes", "")

    st.markdown(
        f"""
        <div class="metric-pill-box">
            <div class="metric-item">
                <div class="metric-item-label">Original Complexity</div>
                <div class="metric-item-value">{html.escape(orig)}</div>
            </div>
            <div class="metric-item">
                <div class="metric-item-label">Corrected Complexity</div>
                <div class="metric-item-value" style="color: #059669;">{html.escape(corr)}</div>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )
    if notes:
        st.caption(f"**Complexity Assessment:** {notes}")


def render_guardrail_notice():
    """Renders mandatory academic guardrail & safety notice."""
    st.markdown(
        """
        <div class="guardrail-notice">
            🛡️ <strong>Academic Guardrail Notice:</strong> DevPulse AI provides educational guidance,
            root-cause explanations, and debugging recommendations. Code is analyzed statically in a safe,
            restricted sandbox — arbitrary user code is <em>never executed</em> directly on the server.
            Always test and verify suggested solutions before integrating into production systems.
        </div>
        """,
        unsafe_allow_html=True
    )
