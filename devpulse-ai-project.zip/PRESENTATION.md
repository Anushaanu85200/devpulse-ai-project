# DevPulse AI — Presentation Slides
**Course:** Grand AI & NLP Student Projects  
**Project No:** 06 — DevPulse AI: Code Explainer and Debugging Tutor  
**Institution:** GMR Institute of Technology (GMRIT)  

---

### Slide 1: Title & Overview
- **Project Name:** DevPulse AI
- **Subtitle:** Intelligent Code Explainer and Socratic Debugging Tutor
- **Domain:** Generative AI & NLP in Software Engineering Education
- **Team / Presenter:** Student Name (GMRIT)
- **Core Mission:** Demystify code errors, explain programming logic, and teach students how to debug methodically.

---

### Slide 2: Problem Statement & Motivation
- **The Challenge:** Beginner programmers get stuck on cryptic error tracebacks (`IndexError`, `ZeroDivisionError`, `NullPointerException`).
- **Common Pitfall:** Copy-pasting errors into search engines or generic chat models returns bulky rewrites without explaining the fundamental mistake.
- **Our Solution:** A dedicated educational debugging tutor that pinpoints root causes, provides surgical minimal fixes, highlights visual diffs, and offers progressive Socratic hints.

---

### Slide 3: System Architecture & Workflow
- **Frontend:** Streamlit 1.41+ with clean, modern SaaS design (crisp slate & indigo theme).
- **Validation Layer (`validators.py`):** Length limits, language normalization, and deterministic Python Abstract Syntax Tree (AST) checking.
- **Core Pipeline (`pipeline.py`):** Structured reasoning prompt, line-by-line diff engine (`difflib`), and complexity analyzer.
- **AI Service (`llm_service.py`):** Multi-provider orchestration supporting Google Gemini API, Groq (LLaMA 3.3), and zero-config Offline Tutor fallback.

---

### Slide 4: Key Features & Innovation
1. **Plain-English Explainer:** Explains algorithmic steps in simple language.
2. **Root-Cause Error Diagnosis:** Explains *why* the bug happened at the exact line.
3. **Minimal Surgical Fix:** Preserves student coding style instead of full rewrites.
4. **Visual Git Diff:** Color-coded additions (`+`) and deletions (`-`).
5. **Socratic Hint-First Mode:** 3-tier progressive hints (Concept Clue ➔ Fault Pinpoint ➔ Near Solution).
6. **Edge-Case Test Generator:** Synthesizes standard and boundary test cases.

---

### Slide 5: Technical Implementation & Code Modularity
- **Clean Separation of Concerns:**
  - `app.py`: Pure presentation layer (no prompts or API calls in UI code).
  - `backend/`: Reusable Python package containing config, validation, LLM service, and core pipeline.
  - `pages/`: History & Analytics (`1_History_and_Analytics.py`) + Interactive Debug Lab (`2_Interactive_Debug_Lab.py`).
  - `data/sample/`: Synthetic buggy samples (Python, JS, Java, C++).

---

### Slide 6: Testing & Quality Assurance
- **Automated Testing:** 13 Pytest test cases covering input validation, AST syntax checks, diff generation, and pipeline outputs.
- **Test Results:** 13/13 Passed (100% test pass rate).
- **Security & Safety Guardrails:** Strict compliance with GMRIT guidelines — server never executes arbitrary user code directly.

---

### Slide 7: Demonstration & Sample Walkthrough
- **Demonstrated Bug:** Python Off-by-one / `IndexError` (`for i in range(len(arr) + 1)`).
- **DevPulse Output:**
  - *Diagnosis:* Identifies that 0-indexed sequences end at `len - 1`.
  - *Minimal Fix:* Changes `len(numbers) + 1` to `len(numbers)`.
  - *Visual Diff:* Shows single-line replacement.
  - *Socratic Hints:* Prompted student to count maximum valid index before revealing code.

---

### Slide 8: Limitations, Ethics & Future Scope
- **Current Limitations:** Real-time deep AST node inspection is currently built for Python; rate limits on free-tier APIs are handled via offline fallback.
- **Academic Ethics:** Educational assistant designed for learning; students are prompted to test and understand code before submitting.
- **Future Scope:** Docker-isolated sandbox execution, IDE extensions for VS Code, and voice-guided debugging tutor.
