"""pages/1_History_and_Analytics.py
DevPulse AI — Session History & Error Analytics
Tracks student debugging sessions, visualizes error categories, and exports reports.
"""

import json
import streamlit as st
import pandas as pd
from components.ui_components import apply_custom_styles, render_guardrail_notice

st.set_page_config(
    page_title="DevPulse AI — History & Analytics",
    page_icon="📊",
    layout="wide"
)

apply_custom_styles()

st.title("📊 Debugging History & Error Analytics")
st.caption("Review all code snippets, errors diagnosed, and fixes generated during your current session.")

history = st.session_state.get("history", [])

if not history:
    st.info("No debugging sessions recorded yet. Go to the main **DevPulse AI** page to analyze a snippet!")
else:
    # Metric cards
    total_runs = len(history)
    languages = [h["language"] for h in history]
    unique_langs = len(set(languages))

    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Code Snippets Debugged", total_runs)
    with col2:
        st.metric("Languages Explored", unique_langs)
    with col3:
        st.metric("Most Frequent Language", pd.Series(languages).mode()[0].upper() if languages else "N/A")

    st.markdown("---")
    st.markdown("### 🕒 Recent Debug Sessions")

    for idx, item in enumerate(reversed(history), start=1):
        full = item.get("full_data", {})
        with st.expander(f"Session #{len(history) - idx + 1}: [{item.get('language', '').upper()}] {item.get('timestamp', '')}"):
            st.markdown(f"**Detected Diagnosis:** {full.get('error_diagnosis', 'N/A')}")
            col_orig, col_corr = st.columns(2)
            with col_orig:
                st.markdown("**Original Code:**")
                st.code(full.get("original_code", ""), language=full.get("language", "python"))
            with col_corr:
                st.markdown("**Corrected Code:**")
                st.code(full.get("corrected_code", ""), language=full.get("language", "python"))

    st.markdown("---")
    st.markdown("### 📥 Export Session History")
    col_dl1, col_dl2 = st.columns(2)

    with col_dl1:
        json_data = json.dumps(history, indent=2)
        st.download_button(
            label="Download Session History (JSON)",
            data=json_data,
            file_name="devpulse_debug_history.json",
            mime="application/json",
            use_container_width=True
        )

    with col_dl2:
        # Markdown summary
        md_lines = ["# DevPulse AI Debugging Session Report\n\n"]
        for idx, h in enumerate(history, 1):
            fd = h.get("full_data", {})
            md_lines.append(f"## Session {idx}: {h.get('language', '').upper()} at {h.get('timestamp')}\n")
            md_lines.append(f"**Diagnosis:** {fd.get('error_diagnosis')}\n\n")
            md_lines.append(f"**Minimal Fix:** {fd.get('minimal_fix_summary')}\n\n")
            md_lines.append(f"```\n{fd.get('corrected_code')}\n```\n\n---\n")

        md_content = "".join(md_lines)
        st.download_button(
            label="Download Session Report (Markdown)",
            data=md_content,
            file_name="devpulse_debug_report.md",
            mime="text/markdown",
            use_container_width=True
        )

render_guardrail_notice()
