"""pages/2_Interactive_Debug_Lab.py
DevPulse AI — Interactive Debug Lab & Syntax Inspector
Provides side-by-side scratchpad comparisons and instant Python AST validation.
"""

import ast
import streamlit as st
from backend.utils.validators import check_python_syntax
from backend.core.pipeline import generate_diff
from components.ui_components import apply_custom_styles, render_diff_viewer, render_guardrail_notice

st.set_page_config(
    page_title="DevPulse AI — Debug Lab & Syntax Inspector",
    page_icon="🔬",
    layout="wide"
)

apply_custom_styles()

st.title("🔬 Interactive Debug Lab & AST Syntax Inspector")
st.caption("Deep-dive tools for students: Inspect Abstract Syntax Trees (AST) and compare two versions of your code side-by-side.")

tab_ast, tab_scratch = st.tabs(["🌳 Python AST Syntax Inspector", "⚖️ Side-by-Side Diff Comparator"])

with tab_ast:
    st.markdown("### 🔍 Real-Time Python AST Syntax Analysis")
    st.write(
        "Detect syntax errors, indentation errors, function definitions, and loop constructs deterministically "
        "using Python's native Abstract Syntax Tree compiler."
    )

    ast_input = st.text_area(
        "Enter Python Code to Inspect",
        value="""def calculate_discount(price, rate):\n    if rate > 1:\n        # Syntax or logic check\n        raise ValueError("Rate must be between 0 and 1")\n    discounted = price * (1 - rate)\n    return discounted\n\nprint(calculate_discount(100, 0.2))""",
        height=180
    )

    if st.button("🔎 Inspect AST Syntax", type="primary"):
        syntax_res = check_python_syntax(ast_input)
        if syntax_res.get("is_valid_syntax"):
            st.success("✅ Code is grammatically valid! No syntax or indentation errors found.")
            metrics = syntax_res.get("metrics", {})
            col_m1, col_m2, col_m3 = st.columns(3)
            with col_m1:
                st.metric("Function Definitions", metrics.get("functions", 0))
            with col_m2:
                st.metric("Classes Declared", metrics.get("classes", 0))
            with col_m3:
                st.metric("Loop Constructs", metrics.get("loops", 0))

            with st.expander("🌲 View Raw AST Structure"):
                parsed_tree = ast.parse(ast_input)
                st.text(ast.dump(parsed_tree, indent=4))
        else:
            st.error(
                f"❌ **{syntax_res.get('error_type')}:** {syntax_res.get('message')} at line {syntax_res.get('line')}, column {syntax_res.get('col')}"
            )
            if syntax_res.get("snippet"):
                st.caption("Faulty Line:")
                st.code(syntax_res.get("snippet"), language="python")

with tab_scratch:
    st.markdown("### ⚖️ Side-by-Side Code Diff Comparator")
    st.write("Compare your original code with your own attempted fix to see exact line additions and deletions.")

    col_left, col_right = st.columns(2)
    with col_left:
        code_v1 = st.text_area("Original Version (Before)", value="for i in range(len(arr) + 1):\n    print(arr[i])", height=150)
    with col_right:
        code_v2 = st.text_area("Revised Version (After)", value="for i in range(len(arr)):\n    print(arr[i])", height=150)

    if st.button("⚡ Compute Unified Diff"):
        diff_output = generate_diff(code_v1, code_v2)
        render_diff_viewer(diff_output)

render_guardrail_notice()
