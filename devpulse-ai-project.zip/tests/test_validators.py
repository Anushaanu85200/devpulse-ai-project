"""tests/test_validators.py
Unit tests for DevPulse AI input and static code validators.
"""

import pytest
from backend.utils.validators import (
    validate_code_input,
    normalize_language,
    check_python_syntax,
    MAX_CODE_CHARS
)


def test_validate_code_input_success():
    """Test 1: Valid Python code snippet passes validation."""
    code = "def add(a, b):\n    return a + b"
    result = validate_code_input(code, "python")
    assert result == code


def test_validate_code_input_empty_fails():
    """Test 2: Empty code raises ValueError."""
    with pytest.raises(ValueError, match="Please provide a code snippet"):
        validate_code_input("", "python")


def test_validate_code_input_whitespace_fails():
    """Test 3: Whitespace only code raises ValueError."""
    with pytest.raises(ValueError, match="Please provide a code snippet"):
        validate_code_input("   \n\t  ", "python")


def test_validate_code_input_too_short():
    """Test 4: Snippet under 3 characters raises ValueError."""
    with pytest.raises(ValueError, match="too short"):
        validate_code_input("x=", "python")


def test_validate_code_input_oversized():
    """Test 5: Snippet exceeding max characters raises ValueError."""
    oversized = "a = 1\n" * (MAX_CODE_CHARS // 5 + 10)
    with pytest.raises(ValueError, match="exceeds the maximum permitted length"):
        validate_code_input(oversized, "python")


def test_normalize_language():
    """Test 6: Language normalization mapping."""
    assert normalize_language("py") == "python"
    assert normalize_language("cpp") == "c++"
    assert normalize_language("js") == "javascript"
    assert normalize_language("cplusplus") == "c++"


def test_check_python_syntax_valid():
    """Test 7: Valid Python syntax produces is_valid_syntax True."""
    valid_code = "for i in range(5):\n    print(i * 2)"
    res = check_python_syntax(valid_code)
    assert res["is_valid_syntax"] is True
    assert res["metrics"]["loops"] == 1


def test_check_python_syntax_invalid():
    """Test 8: Syntax error (missing colon) is deterministically identified."""
    broken_code = "if x > 10\n    print('error')"
    res = check_python_syntax(broken_code)
    assert res["is_valid_syntax"] is False
    assert res["error_type"] in ("SyntaxError", "IndentationError")
    assert res["line"] == 1
