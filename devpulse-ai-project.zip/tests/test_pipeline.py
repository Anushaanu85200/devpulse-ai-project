"""tests/test_pipeline.py
Unit tests for DevPulse AI core pipeline, diff generation, and mock engine.
"""

from backend.core.pipeline import (
    generate_diff,
    extract_json_from_llm,
    process_debug_pipeline
)


def test_generate_diff_additions_and_deletions():
    """Test 1: Unified diff correctly flags changes."""
    orig = "def greet():\n    print('hi')\n"
    corr = "def greet():\n    print('hello world')\n"
    diff = generate_diff(orig, corr)
    assert "-    print('hi')" in diff
    assert "+    print('hello world')" in diff


def test_extract_json_from_llm_with_fences():
    """Test 2: Robustly unpacks JSON enclosed in markdown code fences."""
    raw = '```json\n{"code_explanation": "testing", "corrected_code": "x = 1"}\n```'
    parsed = extract_json_from_llm(raw)
    assert parsed["code_explanation"] == "testing"
    assert parsed["corrected_code"] == "x = 1"


def test_process_debug_pipeline_schema():
    """Test 3: Full pipeline returns all mandatory schema keys."""
    sample_code = "def get_first(items):\n    return items[0]"
    result = process_debug_pipeline(sample_code, language="python")

    expected_keys = [
        "code_explanation",
        "error_diagnosis",
        "minimal_fix_summary",
        "corrected_code",
        "line_by_line_changes",
        "unified_diff",
        "complexity",
        "hints",
        "test_cases",
        "provider_used",
        "mode"
    ]
    for key in expected_keys:
        assert key in result, f"Missing expected key: {key}"


def test_process_debug_pipeline_index_error():
    """Test 4: Pipeline diagnoses off-by-one / IndexError."""
    buggy_code = """def sum_list(lst):
    total = 0
    for i in range(len(lst) + 1):
        total += lst[i]
    return total"""

    res = process_debug_pipeline(
        code=buggy_code,
        language="python",
        error_message="IndexError: list index out of range"
    )
    assert "Index" in res["error_diagnosis"] or "range" in res["error_diagnosis"].lower()
    assert len(res["hints"]) >= 2
    assert len(res["test_cases"]) >= 1


def test_process_debug_pipeline_hints_mode():
    """Test 5: Hints-first mode returns progressive hints."""
    code = "def divide(a, b):\n    return a / b"
    res = process_debug_pipeline(
        code=code,
        language="python",
        error_message="ZeroDivisionError: division by zero",
        mode="hints"
    )
    assert res["mode"] == "hints"
    assert len(res["hints"]) > 0
