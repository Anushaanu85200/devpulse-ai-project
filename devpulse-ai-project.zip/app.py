"""app.py
DevPulse AI — Code Explainer and Debugging Tutor
Main Streamlit application entry point (Frontend).
Designed to meet all specifications of Project 06 in the GMRIT Project Handbook.
"""

import os
import streamlit as st
import pandas as pd

from backend.config import get_active_provider_info, get_setting
from backend.utils.validators import (
    validate_code_input,
    validate_uploaded_file,
    ALLOWED_LANGUAGES,
    normalize_language
)
from backend.core.pipeline import process_debug_pipeline
from components.ui_components import (
    apply_custom_styles,
    render_header,
    render_diff_viewer,
    render_hints_section,
    render_complexity_badge,
    render_guardrail_notice
)

# Page configuration
st.set_page_config(
    page_title="DevPulse AI — Code Explainer & Debugging Tutor",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Apply clean, modern SaaS styling
apply_custom_styles()

# Initialize session state storage
if "history" not in st.session_state:
    st.session_state["history"] = []
if "current_result" not in st.session_state:
    st.session_state["current_result"] = None
if "code_input" not in st.session_state:
    st.session_state["code_input"] = ""
if "error_input" not in st.session_state:
    st.session_state["error_input"] = ""
if "selected_lang" not in st.session_state:
    st.session_state["selected_lang"] = "python"

# Preset sample snippets for quick testing
SAMPLE_PRESETS = {
    "Custom Code (Enter your own)": {
        "lang": "python",
        "code": "",
        "error": ""
    },
    "Python: Off-by-One / IndexError": {
        "lang": "python",
        "code": """def calculate_cumulative_sum(numbers):\n    total = 0\n    # Bug: <= len(numbers) causes IndexError on final iteration\n    for i in range(len(numbers) + 1):\n        total += numbers[i]\n    return total\n\nsample_list = [10, 20, 30, 40]\nprint(calculate_cumulative_sum(sample_list))""",
        "error": "IndexError: list index out of range at line 5 in calculate_cumulative_sum"
    },
    "Python: ZeroDivisionError": {
        "lang": "python",
        "code": """def compute_class_average(scores):\n    # Bug: If scores list is empty, len is 0\n    return sum(scores) / len(scores)\n\nstudent_scores = []\nprint("Average:", compute_class_average(student_scores))""",
        "error": "ZeroDivisionError: division by zero"
    },
    "Python: Mutable Default Argument": {
        "lang": "python",
        "code": """def add_to_cart(item, cart=[]):\n    # Bug: Mutable default list is shared across calls\n    cart.append(item)\n    return cart\n\nuser1_cart = add_to_cart('Laptop')\nuser2_cart = add_to_cart('Headphones')\nprint(user2_cart) # Unexpectedly prints ['Laptop', 'Headphones']""",
        "error": "LogicBug: State leaked across independent calls due to mutable default parameter"
    },
    "JavaScript: Unhandled Null / Promise Rejection": {
        "lang": "javascript",
        "code": """async function getUserDisplayName(userId) {\n    const response = await fetchUserData(userId);\n    // Bug: response or response.profile can be null/undefined\n    return response.profile.firstName + ' ' + response.profile.lastName;\n}\n\nfunction fetchUserData(id) {\n    return Promise.resolve({ profile: null });\n}\n\ngetUserDisplayName(101).then(console.log);""",
        "error": "TypeError: Cannot read properties of null (reading 'firstName')"
    },
    "Java: NullPointerException": {
        "lang": "java",
        "code": """public class WordFilter {\n    public static int getLongestLength(String[] words) {\n        int max = 0;\n        for (String w : words) {\n            // Bug: element can be null in the array\n            if (w.length() > max) {\n                max = w.length();\n            }\n        }\n        return max;\n    }\n}""",
        "error": "Exception in thread 'main' java.lang.NullPointerException at WordFilter.getLongestLength"
    },
    "C++: Dangling Pointer Return": {
        "lang": "c++",
        "code": """#include <iostream>\n\nint* generateSequence() {\n    int count = 100;\n    // Bug: Returning address of stack-allocated local variable\n    return &count;\n}\n\nint main() {\n    int* ptr = generateSequence();\n    std::cout << *ptr << std::endl;\n    return 0;\n}""",
        "error": "Warning / Segfault: address of stack memory associated with local variable 'count' returned"
    }
}

# --- SIDEBAR CONFIGURATION ---
with st.sidebar:
    st.markdown("### ⚙️ Tutor Settings")

    mode_choice = st.selectbox(
        "Tutoring Mode",
        options=[
            ("full", "🚀 Full Debug & Explainer"),
            ("hints", "💡 Socratic Hint-First (Pedagogical)"),
            ("explain", "📖 Code Explainer Only"),
            ("tests", "🧪 Test Suite Generator")
        ],
        format_func=lambda x: x[1],
        index=0,
        help="Select pedagogical mode: Full debug displays everything; Hint-first encourages independent problem-solving."
    )[0]

    st.markdown("---")
    st.markdown("### 🔑 AI Model / Provider")

    # Optional UI Key input
    custom_gemini_key = st.text_input(
        "Google Gemini API Key (Optional)",
        value=get_setting("GEMINI_API_KEY", "") or "",
        type="password",
        help="Enter your free Google Gemini API key from Google AI Studio. If left blank, DevPulse AI uses .env or smart offline tutor mode."
    )
    if custom_gemini_key:
        st.session_state["GEMINI_API_KEY"] = custom_gemini_key

    custom_groq_key = st.text_input(
        "Groq API Key (Optional)",
        value=get_setting("GROQ_API_KEY", "") or "",
        type="password",
        help="Enter Groq API key if using Groq models (e.g. LLaMA 3.3 70B)."
    )
    if custom_groq_key:
        st.session_state["GROQ_API_KEY"] = custom_groq_key

    # Current connectivity status
    provider_info = get_active_provider_info()
    st.caption(f"**Active Engine:** {provider_info['status']}")

    st.markdown("---")
    st.markdown("### 📁 Quick Presets")
    selected_preset = st.selectbox(
        "Load Buggy Sample Code",
        options=list(SAMPLE_PRESETS.keys()),
        index=0
    )

    if selected_preset != "Custom Code (Enter your own)":
        preset_data = SAMPLE_PRESETS[selected_preset]
        if st.button("📥 Apply Sample Code", use_container_width=True):
            st.session_state["code_input"] = preset_data["code"]
            st.session_state["error_input"] = preset_data["error"]
            st.session_state["selected_lang"] = preset_data["lang"]
            st.rerun()

    st.markdown("---")
    if st.button("🔄 Reset Workspace", use_container_width=True):
        st.session_state["code_input"] = ""
        st.session_state["error_input"] = ""
        st.session_state["current_result"] = None
        st.rerun()

# --- MAIN CANVAS ---
render_header(provider_info)

# Input columns
col_lang, col_input_type = st.columns([1, 1])

with col_lang:
    current_lang_idx = 0
    if st.session_state["selected_lang"] in ALLOWED_LANGUAGES:
        current_lang_idx = ALLOWED_LANGUAGES.index(st.session_state["selected_lang"])

    chosen_language = st.selectbox(
        "Programming Language",
        options=ALLOWED_LANGUAGES,
        index=current_lang_idx,
        format_func=lambda x: x.upper()
    )
    st.session_state["selected_lang"] = chosen_language

with col_input_type:
    input_method = st.radio(
        "Input Method",
        options=["Direct Text Editor", "Upload Source File"],
        horizontal=True
    )

uploaded_file_data = None
if input_method == "Upload Source File":
    uploaded_file = st.file_uploader(
        "Upload Source File (.py, .js, .java, .cpp, .sql, .txt)",
        type=["py", "js", "ts", "java", "cpp", "c", "sql", "txt"]
    )
    if uploaded_file is not None:
        try:
            uploaded_file_data = validate_uploaded_file(uploaded_file)
            st.session_state["code_input"] = uploaded_file_data["content"]
            st.session_state["selected_lang"] = uploaded_file_data["language"]
            st.success(f"Loaded {uploaded_file_data['filename']} ({len(uploaded_file_data['content']):,} chars)")
        except ValueError as val_err:
            st.warning(str(val_err))

# Code text area
code_text = st.text_area(
    "Source Code to Explain & Debug",
    value=st.session_state.get("code_input", ""),
    height=220,
    placeholder="Paste your code snippet here...",
    help="Paste any function, block, or module you want to understand or fix."
)
st.session_state["code_input"] = code_text

# Error message input
error_text = st.text_area(
    "Error Message / Traceback (Optional)",
    value=st.session_state.get("error_input", ""),
    height=80,
    placeholder="e.g. IndexError: list index out of range at line 4 (Leave blank if you just want to find logic bugs or explain code)",
    help="Optional compiler, runtime, or terminal error output."
)
st.session_state["error_input"] = error_text

# Action buttons
col_btn1, col_btn2, _ = st.columns([1.5, 1.5, 3])
with col_btn1:
    submit_clicked = st.button("⚡ Diagnose & Debug", type="primary", use_container_width=True)
with col_btn2:
    socratic_clicked = st.button("💡 Get Hints First", use_container_width=True)

active_mode = "hints" if socratic_clicked else mode_choice

# Execution logic
if submit_clicked or socratic_clicked:
    try:
        validated_code = validate_code_input(code_text, chosen_language)
        with st.spinner("Analyzing code, diagnosing errors, and generating tutor feedback..."):
            result = process_debug_pipeline(
                code=validated_code,
                language=chosen_language,
                error_message=error_text,
                mode=active_mode
            )
            st.session_state["current_result"] = result
            # Add to history
            st.session_state["history"].append({
                "timestamp": result["timestamp"],
                "language": result["language"],
                "preview": validated_code[:80].replace("\n", " "),
                "error_detected": result["error_diagnosis"][:80],
                "full_data": result
            })
            st.success("Analysis complete! View the tutor feedback below.")
    except ValueError as val_err:
        st.warning(f"⚠️ Validation Notice: {str(val_err)}")
    except Exception as exc:
        st.error(f"❌ An error occurred during processing: {str(exc)}")

# --- RESULTS DISPLAY WORKSPACE ---
current_res = st.session_state.get("current_result")

if current_res:
    st.markdown("---")
    st.markdown("## 📋 DevPulse AI Diagnosis & Tutor Report")

    # Static AST Alert if present
    ast_data = current_res.get("ast_findings")
    if ast_data and not ast_data.get("is_valid_syntax"):
        st.error(
            f"🔍 **Static Syntax Check Detected an Issue:** {ast_data.get('error_type')} at line {ast_data.get('line')}, column {ast_data.get('col')}: `{ast_data.get('message')}`"
        )
        if ast_data.get("snippet"):
            st.code(ast_data.get("snippet"), language="python")

    # Tabs for structured viewing
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "💡 Explanation & Diagnosis",
        "🛠️ Corrected Code & Changes",
        "⚖️ Diff & Complexity",
        "🧪 Edge Cases & Tests",
        "🎓 Socratic Hints"
    ])

    with tab1:
        st.markdown("### 📖 Plain English Code Explanation")
        st.markdown(current_res.get("code_explanation", "No explanation provided."))

        st.markdown("---")
        st.markdown("### 🚨 Error Diagnosis & Root Cause")
        st.markdown(current_res.get("error_diagnosis", "No error diagnosed."))

        st.markdown("---")
        st.markdown("### 🎯 Minimal Recommended Fix")
        st.info(current_res.get("minimal_fix_summary", "Review corrected code in Tab 2."))

    with tab2:
        st.markdown("### 🛠️ Corrected Code")
        st.caption("Clean, working code preserving your original style with minimal necessary changes:")
        st.code(current_res.get("corrected_code", ""), language=current_res.get("language", "python"))

        st.markdown("### 📝 Line-by-Line Changes Explained")
        changes = current_res.get("line_by_line_changes", [])
        if changes:
            df_changes = pd.DataFrame(changes)
            st.dataframe(df_changes, use_container_width=True, hide_index=True)
        else:
            st.info("No line-by-line modifications required.")

    with tab3:
        st.markdown("### ⚖️ Visual Code Diff (Original vs Corrected)")
        st.caption("Lines highlighted in green (+) are additions; lines in red (-) are removals:")
        render_diff_viewer(current_res.get("unified_diff", ""))

        st.markdown("---")
        st.markdown("### ⏱️ Algorithmic Complexity Comparison")
        render_complexity_badge(current_res.get("complexity", {}))

    with tab4:
        st.markdown("### 🧪 Generated Test Suite & Edge Cases")
        st.caption("Verify your code against standard scenarios and boundary edge cases:")

        test_cases = current_res.get("test_cases", [])
        if test_cases:
            df_tests = pd.DataFrame(test_cases)
            st.dataframe(df_tests, use_container_width=True, hide_index=True)
        else:
            st.info("No test cases generated.")

    with tab5:
        render_hints_section(current_res.get("hints", []))

# Academic guardrails notice
render_guardrail_notice()
