# DevPulse AI — Comprehensive Project Report
**Course / Project:** Grand AI & NLP Student Projects (Project 06)  
**Institution:** GMR Institute of Technology (GMRIT)  
**Title:** DevPulse AI — Intelligent Code Explainer and Socratic Debugging Tutor  

---

## 1. Executive Summary
Programming education requires students to understand why errors occur and how to fix them systematically. Beginners frequently face compiler and runtime errors, leading to frustration and unproductive copy-pasting. **DevPulse AI** is an intelligent educational debugging tutor that deconstructs buggy code, identifies root causes, presents minimal surgical fixes, compares code using visual git diffs, analyzes algorithmic complexity, and provides progressive Socratic hints.

---

## 2. Problem Statement & User Personas
### 2.1 Problem Statement
When students encounter runtime exceptions (e.g., `IndexError`, `ZeroDivisionError`, `NullPointerException`), standard error tracebacks can be intimidating and obscure. Generic AI chat tools often output complete rewrites that introduce foreign concepts without teaching the fundamental flaw.

### 2.2 Target Users
1. **First & Second-Year Programming Students:** Learning syntax, loops, memory management, and data structures.
2. **Competitive Programming & Lab Students:** Seeking to debug logic flaws and edge cases quickly.
3. **Teaching Assistants & Faculty:** Looking for consistent, pedagogical feedback mechanisms.

---

## 3. Project Objectives
- Provide plain-English breakdowns of algorithms and code intent.
- Diagnose root causes of syntax, logic, and runtime errors.
- Supply minimal, line-by-line surgical fixes while preserving student coding styles.
- Support **Socratic Hint-First** learning to stimulate independent thinking.
- Provide real-time deterministic Python AST syntax inspection.
- Enforce strict server-side security (no arbitrary user code execution).

---

## 4. System Architecture & Technical Implementation
### 4.1 Architecture Overview
The system follows a modular architecture separating presentation, validation, core logic, and model orchestration:
- **Presentation Layer (`app.py`, `pages/`, `components/`):** Streamlit interface with clean SaaS aesthetics (no murky dark-web themes).
- **Validation Layer (`backend/utils/validators.py`):** Length limits, language normalization, file upload parsing, and Python AST parsing.
- **Core Engine (`backend/core/pipeline.py`):** Prompt formulation, schema extraction, unified git diff generation via `difflib`, and complexity comparison.
- **AI Service Layer (`backend/services/llm_service.py`):** Dual-provider support for Google Gemini (`gemini-1.5-flash`) and Groq (`llama-3.3-70b-versatile`), with an automatic zero-config offline rule tutor.

---

## 5. Test Evidence & Results (13 Test Cases)

| Test ID | Test Scenario / Input | Expected Result | Actual Result | Status |
|---|---|---|---|---|
| TC-01 | Valid Python code input (`def add(a, b): return a + b`) | Input passes validation cleanly | Passed identical string | **PASS** |
| TC-02 | Empty string input (`""`) | Raises `ValueError` ("Please provide a code snippet") | Raised `ValueError` with helpful message | **PASS** |
| TC-03 | Whitespace only input (`"   \n\t  "`) | Raises `ValueError` | Raised `ValueError` | **PASS** |
| TC-04 | Under 3 characters input (`"x="`) | Raises `ValueError` ("too short") | Raised `ValueError` | **PASS** |
| TC-05 | Oversized input (> 30,000 characters) | Raises `ValueError` ("exceeds max characters") | Raised `ValueError` | **PASS** |
| TC-06 | Language normalization (`"cpp"`, `"py"`) | Normalized to `"c++"`, `"python"` | Correctly mapped | **PASS** |
| TC-07 | Valid Python AST syntax parsing | `is_valid_syntax=True`, count functions & loops | Detected valid syntax, 1 loop | **PASS** |
| TC-08 | Broken Python syntax (`if x > 10\n print(1)`) | Deterministically reports `SyntaxError` at line 1 | Detected `SyntaxError` at line 1 | **PASS** |
| TC-09 | Unified Diff generation (`print('hi')` to `'hello'`) | Generates git diff with `-` and `+` lines | Diff produced with `-` and `+` markers | **PASS** |
| TC-10 | Markdown-wrapped JSON extraction | Unpacks JSON cleanly from code fences | Parsed dictionary accurately | **PASS** |
| TC-11 | Full pipeline output schema check | Result contains all 11 mandatory keys | All keys present and valid | **PASS** |
| TC-12 | Off-by-one / IndexError diagnosis | Root cause identifies index bounds error | Diagnosed off-by-one with hints | **PASS** |
| TC-13 | Socratic hints-first mode | Returns progressive hints (Levels 1-3) | 3 progressive hints generated | **PASS** |

---

## 6. Known Limitations & Security Considerations
1. **No Arbitrary Code Execution:** The system never compiles or runs user code on the server host to prevent remote code execution (RCE) attacks.
2. **API Rate Limits:** Free-tier Gemini and Groq API keys operate under standard rate limits. When limits are exceeded, the app falls back smoothly to offline heuristic analysis.

---

## 7. Conclusion & Future Scope
DevPulse AI provides an effective, secure, and educational debugging tutor that satisfies all requirements of Project 06 in the GMRIT Handbook. Future extensions include Dockerized client-side sandboxes and multi-language AST trees for JavaScript and C++.
